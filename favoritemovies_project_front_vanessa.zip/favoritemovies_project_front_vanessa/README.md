# FAVORITEMOVIES_project_front_vanessa

A Pen created on CodePen.io. Original URL: [https://codepen.io/vanefati/pen/eYxGxXb](https://codepen.io/vanefati/pen/eYxGxXb).

My List of favorite films on Streaming platforms.