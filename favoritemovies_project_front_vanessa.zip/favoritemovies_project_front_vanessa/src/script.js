
var listaDeFilmes = [
  
'https://br.web.img3.acsta.net/medias/nmedia/18/93/94/02/20287510.jpg','https://br.web.img3.acsta.net/pictures/17/12/07/11/33/0502209.jpg',
 'https://imagens.publicocdn.com/imagens.aspx/788035?tp=KM','https://images-na.ssl-images-amazon.com/images/S/pv-target-images/12d1383fb1463ffb58ef724a181a09e661afe63ff8498a4296d10b35ec2a1bbc._RI_TTW_.jpg','https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTsKBl6BxO5Zsr662A96FnzRmOyhPgnj8bD9pK3jzDk1kKtE6LJ0CezvYE_Dg9aTky2cOw&usqp=CAU' 
  
];

var nomeDeFilmes = [' O JARDIM SECRETO',' VIVA A VIDA É UMA FESTA', 'WEDNESDAY', 'O MiISTÉRIO DA FEIURINHA', 'A ESCOLA DO BEM E DO MAL'];

 
for (var i = 0; i < listaDeFilmes.length; i++) {
 document.write('<img src =' + listaDeFilmes [i] +'>')
 document.write('<br>' + nomeDeFilmes [i] +'<br>');
}
  
